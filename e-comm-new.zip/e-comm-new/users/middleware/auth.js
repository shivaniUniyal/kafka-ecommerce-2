const jwt = require("jsonwebtoken");
// const producer = require("../../kafka/producer");
const consumer = require("../../gateway/kafka/consumer")

const config = process.env;

const verifyToken = async () => {


  
};
verifyToken();
//req.body.token || req.query.token || req.headers["x-access-token"] ||