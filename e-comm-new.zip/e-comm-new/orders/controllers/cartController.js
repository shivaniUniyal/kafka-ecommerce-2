const mongoose = require("mongoose");
const cartModel = require("../models/cartModel");
const cart = mongoose.model("Cart", cartModel);

const createCart = async (productData) => {
  try {
    productData = JSON.parse(productData);
    let cartExist = await cart.findOne({ user_id: productData.userId });
    if (cartExist) {
      let productIndex = cartExist.products.findIndex(item => item.product_id == productData.product_id);
      let previous_quantity;
      if (productIndex >= 0 && productData.quantity > 0) {
        previous_quantity = cartExist.products[productIndex].quantity;
        cartExist.products[productIndex].quantity = productData.quantity;
        cartExist.total_price = (cartExist.total_price - (productData.product_price * previous_quantity));
        cartExist.total_price += productData.quantity * productData.product_price;
        let result = await cart.findByIdAndUpdate(cartExist._id, cartExist);
        if (cartExist.total_price == 0) {
          await cart.findByIdAndDelete({ _id: cartExist._id });
        }
        console.log({ message: "Product added to cart successfully" });
      } else if (productIndex >= 0 && productData.quantity == 0) {
        previous_quantity = cartExist.products[productIndex].quantity;
        cartExist.products.splice(productIndex, 1);
        cartExist.total_price = (cartExist.total_price - (productData.product_price * previous_quantity)) + (productData.quantity * productData.product_price);

        let result = await cart.findByIdAndUpdate(cartExist._id, cartExist);
        res.status(200).json({ message: "Product removed successfully as quantity is 0." });
        if (cartExist.total_price == 0) {
          await cart.findByIdAndDelete({ _id: cartExist._id });
        }
      } else {
        cartExist.products.push({ product_id: productData.product_id, quantity: productData.quantity });
        cartExist.total_price += (productData.quantity * productData.product_price);
        await cart.findByIdAndUpdate(cartExist._id, cartExist);
       console.log({ message: "Product added to cart successfully" });
      }
    } else {
      let product_price = productData.product_price;
      let cartData = { user_id: productData.userId, products: [{ product_id: productData.product_id, quantity: productData.quantity }], total_price: product_price * productData.quantity };
      let newCart = new cart(cartData);
      let result = await newCart.save();
      console.log("Product added to cart successfully");
    }

  } catch (err) {
    console.log(`error occur ${err.message}`);
  }
};
module.exports = { createCart };