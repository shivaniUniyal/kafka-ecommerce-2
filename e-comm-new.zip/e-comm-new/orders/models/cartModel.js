const mongoose = require("mongoose");

const userCart = mongoose.Schema(
  {
    user_id: {
      type: mongoose.Schema.Types.ObjectId,
      required: [true, "User id is required."],
      ref: "user",
    },
    products: [
      {
        product_id: {
          type: String,
          required: [true, "Product title is required."],
        },
        quantity: {
          type: Number,
          required: [true, "Product description is required."],
        },
      },
    ],
    total_price: {
      type: Number,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

module.exports = userCart;
