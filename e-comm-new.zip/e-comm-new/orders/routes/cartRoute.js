//Include express functionalities
const app = require("express").Router();
const auth = require("../middleware/auth");
const {
    createCart
} = require("../controllers/cartController");

//===================================Cart create api================================================================

//app.post("/add", addCart);
app.route("/add").post(auth, createCart);

module.exports = app;