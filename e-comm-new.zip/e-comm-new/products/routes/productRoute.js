//Include express functionalities
const app = require("express").Router();
const verifyToken = require("../middleware/auth");

const {
    viewProduct,addProduct,listProduct,addCart
} = require("../controllers/productController");

app.get('/',verifyToken,  listProduct);
app.post('/product/add',verifyToken, addProduct);
app.get('/product/view',verifyToken, viewProduct);
app.post('/product/cart',verifyToken,addCart);
module.exports = app;