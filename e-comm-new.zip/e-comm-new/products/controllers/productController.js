const mongoose = require("mongoose");
const productModel = require("../models/productModel");
const producer = require("../../gateway/kafka/producer");
const product = mongoose.model("Product", productModel);


//=============================VIEW PRODUCT====================================================================

const viewProduct = async (req, res, next) => {
  let productId = req.query.id;
  try {

    let result = await product.findOne({ _id: productId });
    if (result) {
      res.status(200).json({ message: "Product fetched successfully.", data: [result] });
    } else {
      res.status(500).json({ message: "Invalid product id" });
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

//=============================ADD PRODUCT=====================================================================

const addProduct = async (req, res, next) => {
  let data = req.body;
  try {
    let isTitleAlreadyExist = await product.findOne({ product_title: req.body.product_title, });
    if (!isTitleAlreadyExist) {
      let newProduct = new product(data);
      let result = await newProduct.save();
      res.status(200).json({ message: "Product added successfully", data: result });
    } else {
      res.status(400).json({ message: "Title already exists" });
    }
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
}

//=============================LIST ALL PRODUCT================================================================

const listProduct = async (req, res, next) => {
  try {

    let result = await product.find({});
    console.log("Message Sent: ", "list of products")
    await producer.send({
      topic: 'test-topic-new',
      messages: [
        { value: JSON.stringify(result) },
      ],
    })
    res.status(200).json({
      message: "Products fetched successfully",
      data: result,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

//=============================ADD CART========================================================================

const addCart = async (req, res, next) => {
   let userId = req.user.user_id;
  console.log("add cart called");
  let productData = req.body;
  productData.userId = userId;
  try {
    let isProductIdExist = await product.findOne({ _id: productData.product_id });
    if (isProductIdExist) {
      productData.product_price = isProductIdExist.price;
      productData.stock = isProductIdExist.quantity;
      productData.name = isProductIdExist.name;

      if (productData.quantity <= isProductIdExist.quantity) {
        await producer.send({
          topic: 'order-topic',
          messages: [
            { value: JSON.stringify(productData) },
          ],
        })
        
        res.status(200).json({ message: "data fetched succesfully", data: productData });
      } else {
        res.status(400).json({ message: `Only ${isProductIdExist.quantity} stock is available for this product.` });
      }
    } else {
      res.status(400).json({ message: "Invalid product id." });
    }
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

module.exports = { viewProduct, addProduct, listProduct, addCart };